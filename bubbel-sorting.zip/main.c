#include<stdio.h>
int main()
{
    int n=20,a[n],temp,i,b,j;
    printf("Enter the size = ");
    scanf("%d",&n);
    printf("Enter %d array elements = ",n);
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    for(i=0;i<n;i++)
    {
        for(j=0;j<n-i-1;j++)
        {
            if(a[j]>a[j+1])
            {
                temp=a[j];
                a[j]=a[j+1];
                a[j+1]=temp;
            }
            
        }
        printf("\nAfter pass %d\n",i+1);
        for(b=0;b<n;b++)
            {
                
                printf("%d ",a[b]);
            }
       
       
        
    }
    printf("\nsorted elements are = \n");
    for(i=0;i<n;i++)
    {
       
        printf("%d\t",a[i]);
    }
    return 0;
}